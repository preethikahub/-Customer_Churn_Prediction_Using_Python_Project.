import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Database, 
  Search, 
  Settings2, 
  BarChart3, 
  Cpu, 
  CheckCircle2, 
  Lightbulb,
  ChevronRight,
  Code2,
  Table as TableIcon,
  PieChart as PieChartIcon,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

// --- Mock Data for Visualizations ---

const churnDistribution = [
  { name: 'Retained', value: 5174 },
  { name: 'Churned', value: 1869 },
];

const COLORS = ['#10b981', '#ef4444'];

const tenureVsChurn = [
  { tenure: '0-12', Retained: 800, Churned: 1100 },
  { tenure: '13-24', Retained: 950, Churned: 400 },
  { tenure: '25-36', Retained: 1100, Churned: 250 },
  { tenure: '37-48', Retained: 1200, Churned: 100 },
  { tenure: '49-60', Retained: 1300, Churned: 50 },
  { tenure: '61-72', Retained: 1500, Churned: 20 },
];

const featureImportance = [
  { feature: 'Contract_Month-to-month', importance: 0.28 },
  { feature: 'Tenure', importance: 0.18 },
  { feature: 'TotalCharges', importance: 0.14 },
  { feature: 'MonthlyCharges', importance: 0.12 },
  { feature: 'OnlineSecurity_No', importance: 0.09 },
  { feature: 'TechSupport_No', importance: 0.08 },
  { feature: 'InternetService_Fiber optic', importance: 0.06 },
  { feature: 'PaperlessBilling', importance: 0.05 },
];

const modelPerformance = [
  { metric: 'Accuracy', LogisticRegression: 0.80, RandomForest: 0.82 },
  { metric: 'Precision', LogisticRegression: 0.65, RandomForest: 0.68 },
  { metric: 'Recall', LogisticRegression: 0.55, RandomForest: 0.52 },
  { metric: 'F1-Score', LogisticRegression: 0.59, RandomForest: 0.59 },
  { metric: 'ROC-AUC', LogisticRegression: 0.84, RandomForest: 0.85 },
];

const sampleData = [
  { customerID: '7590-VHVEG', gender: 'Female', SeniorCitizen: 0, Partner: 'Yes', Dependents: 'No', tenure: 1, PhoneService: 'No', MultipleLines: 'No phone service', InternetService: 'DSL', OnlineSecurity: 'No', OnlineBackup: 'Yes', DeviceProtection: 'No', TechSupport: 'No', StreamingTV: 'No', StreamingMovies: 'No', Contract: 'Month-to-month', PaperlessBilling: 'Yes', PaymentMethod: 'Electronic check', MonthlyCharges: 29.85, TotalCharges: '29.85', Churn: 'No' },
  { customerID: '5575-GNVDE', gender: 'Male', SeniorCitizen: 0, Partner: 'No', Dependents: 'No', tenure: 34, PhoneService: 'Yes', MultipleLines: 'No', InternetService: 'DSL', OnlineSecurity: 'Yes', OnlineBackup: 'No', DeviceProtection: 'Yes', TechSupport: 'No', StreamingTV: 'No', StreamingMovies: 'No', Contract: 'One year', PaperlessBilling: 'No', PaymentMethod: 'Mailed check', MonthlyCharges: 56.95, TotalCharges: '1889.5', Churn: 'No' },
  { customerID: '3668-QPYBK', gender: 'Male', SeniorCitizen: 0, Partner: 'No', Dependents: 'No', tenure: 2, PhoneService: 'Yes', MultipleLines: 'No', InternetService: 'DSL', OnlineSecurity: 'Yes', OnlineBackup: 'Yes', DeviceProtection: 'No', TechSupport: 'No', StreamingTV: 'No', StreamingMovies: 'No', Contract: 'Month-to-month', PaperlessBilling: 'Yes', PaymentMethod: 'Mailed check', MonthlyCharges: 53.85, TotalCharges: '108.15', Churn: 'Yes' },
  { customerID: '7795-CFOCW', gender: 'Male', SeniorCitizen: 0, Partner: 'No', Dependents: 'No', tenure: 45, PhoneService: 'No', MultipleLines: 'No phone service', InternetService: 'DSL', OnlineSecurity: 'Yes', OnlineBackup: 'No', DeviceProtection: 'Yes', TechSupport: 'Yes', StreamingTV: 'No', StreamingMovies: 'No', Contract: 'One year', PaperlessBilling: 'No', PaymentMethod: 'Bank transfer (automatic)', MonthlyCharges: 42.3, TotalCharges: '1840.75', Churn: 'No' },
  { customerID: '9237-HQITU', gender: 'Female', SeniorCitizen: 0, Partner: 'No', Dependents: 'No', tenure: 2, PhoneService: 'Yes', MultipleLines: 'No', InternetService: 'Fiber optic', OnlineSecurity: 'No', OnlineBackup: 'No', DeviceProtection: 'No', TechSupport: 'No', StreamingTV: 'No', StreamingMovies: 'No', Contract: 'Month-to-month', PaperlessBilling: 'Yes', PaymentMethod: 'Electronic check', MonthlyCharges: 70.7, TotalCharges: '151.65', Churn: 'Yes' },
];

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group",
      active 
        ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
        : "text-slate-500 hover:bg-slate-100 hover:text-slate-900"
    )}
  >
    <Icon size={20} className={cn(active ? "text-white" : "text-slate-400 group-hover:text-slate-600")} />
    <span className="font-medium text-sm">{label}</span>
    {active && (
      <motion.div 
        layoutId="active-pill"
        className="ml-auto w-1.5 h-1.5 rounded-full bg-white"
      />
    )}
  </button>
);

const SectionHeader = ({ title, icon: Icon, description }: { title: string, icon: any, description: string }) => (
  <div className="mb-8">
    <div className="flex items-center gap-3 mb-2">
      <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
        <Icon size={24} />
      </div>
      <h2 className="text-2xl font-bold text-slate-900">{title}</h2>
    </div>
    <p className="text-slate-500 max-w-2xl">{description}</p>
  </div>
);

const CodeBlock = ({ code }: { code: string }) => (
  <div className="rounded-xl overflow-hidden border border-slate-200 my-4 shadow-sm">
    <div className="bg-slate-800 px-4 py-2 flex items-center justify-between">
      <div className="flex gap-1.5">
        <div className="w-3 h-3 rounded-full bg-red-500" />
        <div className="w-3 h-3 rounded-full bg-yellow-500" />
        <div className="w-3 h-3 rounded-full bg-green-500" />
      </div>
      <span className="text-xs font-mono text-slate-400">churn_prediction.py</span>
    </div>
    <SyntaxHighlighter 
      language="python" 
      style={vscDarkPlus}
      customStyle={{ margin: 0, padding: '1.5rem', fontSize: '0.875rem' }}
    >
      {code}
    </SyntaxHighlighter>
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState('collection');

  const tabs = [
    { id: 'collection', label: 'Data Collection', icon: Database },
    { id: 'exploration', label: 'Data Exploration', icon: Search },
    { id: 'preprocessing', label: 'Preprocessing', icon: Settings2 },
    { id: 'eda', label: 'EDA', icon: BarChart3 },
    { id: 'modeling', label: 'Model Training', icon: Cpu },
    { id: 'evaluation', label: 'Evaluation', icon: CheckCircle2 },
    { id: 'insights', label: 'Business Insights', icon: Lightbulb },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'collection':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Data Collection" 
              icon={Database}
              description="Loading the telecom customer churn dataset and performing initial inspection of the raw data."
            />
            
            <CodeBlock code={`import pandas as pd
import numpy as np

# Load the dataset
df = pd.read_csv('telecom_churn.csv')

# Display basic info
print(df.info())
print(df.head())`} />

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="flex items-center gap-2 mb-4">
                <TableIcon size={18} className="text-indigo-600" />
                <h3 className="font-semibold text-slate-800">Dataset Preview (First 5 Rows)</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-500">
                  <thead className="text-xs text-slate-700 uppercase bg-slate-50">
                    <tr>
                      {Object.keys(sampleData[0]).slice(0, 8).map(key => (
                        <th key={key} className="px-4 py-3 font-semibold">{key}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {sampleData.map((row, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        {Object.values(row).slice(0, 8).map((val, j) => (
                          <td key={j} className="px-4 py-3 whitespace-nowrap">{val}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 p-3 bg-indigo-50 rounded-lg flex items-center gap-3">
                <AlertCircle size={18} className="text-indigo-600" />
                <p className="text-xs text-indigo-800">
                  The dataset contains 7,043 entries and 21 features including demographics, services, and account information.
                </p>
              </div>
            </div>
          </motion.div>
        );

      case 'exploration':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Data Exploration" 
              icon={Search}
              description="Analyzing the target variable distribution and identifying data quality issues like missing values."
            />

            <CodeBlock code={`# Check for missing values
print(df.isnull().sum())

# Explore Churn distribution
churn_counts = df['Churn'].value_counts()
print(churn_counts)`} />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-semibold text-slate-800 mb-6 flex items-center gap-2">
                  <PieChartIcon size={18} className="text-indigo-600" />
                  Churn Distribution
                </h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={churnDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {churnDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-8 mt-4">
                  {churnDistribution.map((entry, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                      <span className="text-sm text-slate-600">{entry.name}: {((entry.value / 7043) * 100).toFixed(1)}%</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-semibold text-slate-800 mb-6">Data Quality Summary</h3>
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium text-slate-700">Missing Values</span>
                      <span className="text-sm font-bold text-green-600">0 Found</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full w-0" />
                    </div>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium text-slate-700">Total Charges Type Error</span>
                      <span className="text-sm font-bold text-amber-600">11 Rows</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full w-[15%]" />
                    </div>
                    <p className="text-[10px] text-slate-500 mt-2 italic">Note: Some TotalCharges values are empty strings and need conversion.</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 'preprocessing':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Data Preprocessing" 
              icon={Settings2}
              description="Cleaning data, encoding categorical variables, and preparing features for the machine learning models."
            />

            <CodeBlock code={`# Convert TotalCharges to numeric
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
df.dropna(inplace=True)

# Encode categorical variables
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
df['Churn'] = le.fit_transform(df['Churn'])

# One-hot encoding for other features
df = pd.get_dummies(df, drop_first=True)`} />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { title: 'Data Cleaning', desc: 'Handled 11 missing values in TotalCharges by converting to numeric and dropping nulls.' },
                { title: 'Feature Encoding', desc: 'Binary features encoded to 0/1. Multi-class features transformed via One-Hot Encoding.' },
                { title: 'Feature Scaling', desc: 'Numerical features like MonthlyCharges and Tenure scaled to ensure model convergence.' }
              ].map((item, i) => (
                <div key={i} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
                  <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600 mb-4">
                    <CheckCircle2 size={20} />
                  </div>
                  <h4 className="font-bold text-slate-900 mb-2">{item.title}</h4>
                  <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>
        );

      case 'eda':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Exploratory Data Analysis" 
              icon={BarChart3}
              description="Uncovering patterns and relationships between features and customer churn."
            />

            <CodeBlock code={`import seaborn as sns
import matplotlib.pyplot as plt

# Tenure vs Churn
plt.figure(figsize=(10,6))
sns.histplot(data=df, x='tenure', hue='Churn', multiple='stack')
plt.title('Tenure Distribution by Churn')`} />

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="font-semibold text-slate-800 mb-6 flex items-center gap-2">
                <TrendingUp size={18} className="text-indigo-600" />
                Tenure vs Churn (Stacked Distribution)
              </h3>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={tenureVsChurn}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="tenure" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="Retained" stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="Churned" stackId="a" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="mt-4 text-sm text-slate-500 text-center">
                Insight: New customers (0-12 months) have a significantly higher churn rate compared to long-term customers.
              </p>
            </div>
          </motion.div>
        );

      case 'modeling':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Model Training" 
              icon={Cpu}
              description="Splitting data and training multiple classifiers to predict churn."
            />

            <CodeBlock code={`from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

X = df.drop('Churn', axis=1)
y = df['Churn']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Models
lr = LogisticRegression()
lr.fit(X_train, y_train)

rf = RandomForestClassifier(n_estimators=100)
rf.fit(X_train, y_train)`} />

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="font-semibold text-slate-800 mb-6">Model Comparison</h3>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={modelPerformance} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                    <XAxis type="number" domain={[0, 1]} axisLine={false} tickLine={false} />
                    <YAxis dataKey="metric" type="category" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="LogisticRegression" fill="#6366f1" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="RandomForest" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </motion.div>
        );

      case 'evaluation':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Model Evaluation" 
              icon={CheckCircle2}
              description="Assessing model performance using various metrics and identifying the most important features."
            />

            <CodeBlock code={`from sklearn.metrics import classification_report, confusion_matrix

y_pred = rf.predict(X_test)
print(classification_report(y_test, y_pred))

# Feature Importance
importances = rf.feature_importances_
feature_df = pd.DataFrame({'Feature': X.columns, 'Importance': importances})
print(feature_df.sort_values('Importance', ascending=False).head(10))`} />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-semibold text-slate-800 mb-6">Top Feature Importance</h3>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={featureImportance} layout="vertical">
                      <XAxis type="number" hide />
                      <YAxis dataKey="feature" type="category" width={150} axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="importance" fill="#4f46e5" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-slate-900 p-6 rounded-2xl text-white">
                  <h3 className="font-semibold mb-4 text-slate-400 uppercase text-xs tracking-wider">Classification Report (Random Forest)</h3>
                  <div className="font-mono text-sm space-y-2">
                    <div className="grid grid-cols-4 text-slate-500 border-b border-slate-800 pb-2">
                      <span>Metric</span>
                      <span>Precision</span>
                      <span>Recall</span>
                      <span>F1-Score</span>
                    </div>
                    <div className="grid grid-cols-4 py-1">
                      <span className="text-slate-400">Class 0</span>
                      <span>0.85</span>
                      <span>0.91</span>
                      <span>0.88</span>
                    </div>
                    <div className="grid grid-cols-4 py-1">
                      <span className="text-slate-400">Class 1</span>
                      <span className="text-indigo-400">0.68</span>
                      <span className="text-indigo-400">0.52</span>
                      <span className="text-indigo-400">0.59</span>
                    </div>
                    <div className="grid grid-cols-4 pt-4 border-t border-slate-800 font-bold">
                      <span className="text-slate-400">Accuracy</span>
                      <span className="col-span-3 text-right">0.82</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <h3 className="font-semibold text-slate-800 mb-4">Evaluation Summary</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">
                    The Random Forest model achieved an accuracy of 82%. While it predicts retained customers very well, the recall for churned customers (Class 1) is 52%, suggesting we might need to adjust the decision threshold or use oversampling techniques like SMOTE.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 'insights':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <SectionHeader 
              title="Business Insights" 
              icon={Lightbulb}
              description="Translating model results into actionable strategies for the business."
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-10">
                  <TrendingUp size={120} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Why Customers Churn?</h3>
                <ul className="space-y-4">
                  {[
                    { title: 'Contract Type', desc: 'Month-to-month contracts are the strongest predictor of churn. Customers lack long-term commitment.' },
                    { title: 'New Customers', desc: 'The first 12 months are critical. High churn rates observed in early tenure stages.' },
                    { title: 'Fiber Optic Service', desc: 'Surprisingly, fiber optic users churn more, possibly due to higher costs or service stability issues.' },
                    { title: 'Lack of Support', desc: 'Customers without Online Security or Tech Support services are more likely to leave.' }
                  ].map((item, i) => (
                    <li key={i} className="flex gap-3">
                      <div className="mt-1 w-5 h-5 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <div className="w-2 h-2 rounded-full bg-red-500" />
                      </div>
                      <div>
                        <span className="font-bold text-slate-800 block">{item.title}</span>
                        <span className="text-sm text-slate-500">{item.desc}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-indigo-600 p-8 rounded-3xl text-white shadow-xl shadow-indigo-200">
                <h3 className="text-xl font-bold mb-6">Actionable Strategies</h3>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                      <ChevronRight size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Incentivize Long-term Contracts</h4>
                      <p className="text-sm text-indigo-100">Offer discounts or bundled services for customers switching from month-to-month to one or two-year contracts.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                      <ChevronRight size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Targeted Retention for Newbies</h4>
                      <p className="text-sm text-indigo-100">Implement a "First Year" loyalty program with proactive support calls at month 3 and 6.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                      <ChevronRight size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Bundle Security Services</h4>
                      <p className="text-sm text-indigo-100">Include Online Security and Tech Support as standard features in premium plans to increase "stickiness".</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col sticky top-0 h-screen">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <TrendingUp size={24} />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">ChurnAI</h1>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Data Science Project</p>
            </div>
          </div>

          <nav className="space-y-1">
            {tabs.map((tab) => (
              <SidebarItem
                key={tab.id}
                icon={tab.icon}
                label={tab.label}
                active={activeTab === tab.id}
                onClick={() => setActiveTab(tab.id)}
              />
            ))}
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-slate-100">
          <div className="bg-slate-50 p-4 rounded-2xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
              <Code2 size={20} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">Python 3.9</p>
              <p className="text-[10px] text-slate-500">Scikit-Learn v1.0</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 px-10 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span>Project</span>
            <ChevronRight size={14} />
            <span className="text-slate-900 font-medium">Customer Churn Prediction</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="px-4 py-2 bg-slate-900 text-white text-sm font-medium rounded-lg hover:bg-slate-800 transition-colors">
              Export Report
            </button>
          </div>
        </header>

        <div className="max-w-5xl mx-auto p-10">
          <AnimatePresence mode="wait">
            {renderContent()}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

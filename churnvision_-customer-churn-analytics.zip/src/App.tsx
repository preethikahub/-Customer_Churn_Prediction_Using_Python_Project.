/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, ScatterChart, Scatter, ZAxis
} from 'recharts';
import { 
  Database, Search, Settings, BarChart3, Cpu, CheckCircle2, 
  Lightbulb, Code2, ChevronRight, LayoutDashboard, FileText,
  TrendingUp, Users, DollarSign, AlertTriangle, Terminal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Mock Data
import { mockChurnData, featureImportance, modelMetrics, confusionMatrix } from './data';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6'];

const CodeBlock = ({ code }: { code: string }) => (
  <div className="bg-slate-900 rounded-lg p-4 my-4 font-mono text-sm text-slate-300 overflow-x-auto border border-slate-800 shadow-inner">
    <div className="flex items-center gap-2 mb-2 text-slate-500 border-b border-slate-800 pb-2">
      <Terminal size={14} />
      <span>Python Code</span>
    </div>
    <pre><code>{code}</code></pre>
  </div>
);

const SectionHeader = ({ title, icon: Icon, step }: { title: string, icon: any, step: number }) => (
  <div className="flex items-center gap-3 mb-6">
    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
      {step}
    </div>
    <div className="flex items-center gap-2">
      <Icon className="text-slate-400" size={24} />
      <h2 className="text-2xl font-bold text-slate-800">{title}</h2>
    </div>
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');

  const churnDist = useMemo(() => {
    const counts = mockChurnData.reduce((acc: any, curr) => {
      acc[curr.Churn] = (acc[curr.Churn] || 0) + 1;
      return acc;
    }, {});
    return Object.keys(counts).map(key => ({ name: key, value: counts[key] }));
  }, []);

  const tenureVsChurn = useMemo(() => {
    return mockChurnData.map(d => ({
      tenure: d.tenure,
      MonthlyCharges: d.MonthlyCharges,
      Churn: d.Churn === 'Yes' ? 1 : 0
    })).sort((a, b) => a.tenure - b.tenure);
  }, []);

  const steps = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'collection', label: 'Data Collection', icon: Database },
    { id: 'exploration', label: 'Data Exploration', icon: Search },
    { id: 'preprocessing', label: 'Preprocessing', icon: Settings },
    { id: 'eda', label: 'EDA', icon: BarChart3 },
    { id: 'training', label: 'Model Training', icon: Cpu },
    { id: 'evaluation', label: 'Evaluation', icon: CheckCircle2 },
    { id: 'insights', label: 'Insights', icon: Lightbulb },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col sticky top-0 h-screen">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center gap-2 text-blue-600 mb-1">
            <TrendingUp size={24} />
            <span className="font-black text-xl tracking-tighter">CHURNVISION</span>
          </div>
          <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Analytics Dashboard</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {steps.map((step) => (
            <button
              key={step.id}
              onClick={() => setActiveTab(step.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
                activeTab === step.id 
                  ? "bg-blue-50 text-blue-600 shadow-sm" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"
              )}
            >
              <step.icon size={20} className={cn(
                "transition-transform group-hover:scale-110",
                activeTab === step.id ? "text-blue-600" : "text-slate-400"
              )} />
              <span className="font-semibold text-sm">{step.label}</span>
              {activeTab === step.id && (
                <motion.div layoutId="active-pill" className="ml-auto">
                  <ChevronRight size={16} />
                </motion.div>
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3 px-2 py-2">
            <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
              <Code2 size={16} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-700">Python Project</p>
              <p className="text-[10px] text-slate-400">v1.0.4 Stable</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8 lg:p-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="max-w-5xl mx-auto"
          >
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">Customer Churn Prediction Project</h1>
                  <p className="text-lg text-slate-600 leading-relaxed max-w-3xl">
                    Customer churn is a critical metric for telecom companies. This project demonstrates a complete data science pipeline 
                    to identify customers likely to leave, enabling proactive retention strategies.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
                      <Users size={24} />
                    </div>
                    <h3 className="text-lg font-bold mb-2">7,043 Customers</h3>
                    <p className="text-sm text-slate-500">Total records analyzed in the telecom dataset.</p>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center mb-4">
                      <AlertTriangle size={24} />
                    </div>
                    <h3 className="text-lg font-bold mb-2">26.5% Churn Rate</h3>
                    <p className="text-sm text-slate-500">Average percentage of customers leaving monthly.</p>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div className="w-12 h-12 rounded-xl bg-green-100 text-green-600 flex items-center justify-center mb-4">
                      <DollarSign size={24} />
                    </div>
                    <h3 className="text-lg font-bold mb-2">$86M Revenue Risk</h3>
                    <p className="text-sm text-slate-500">Estimated annual revenue loss due to churn.</p>
                  </div>
                </div>

                <div className="bg-blue-600 rounded-3xl p-8 text-white relative overflow-hidden shadow-xl shadow-blue-200">
                  <div className="relative z-10">
                    <h2 className="text-2xl font-bold mb-4">Project Objectives</h2>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-2">
                        <CheckCircle2 size={18} className="text-blue-200" />
                        <span>Perform deep Exploratory Data Analysis (EDA)</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 size={18} className="text-blue-200" />
                        <span>Preprocess and engineer features for ML models</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 size={18} className="text-blue-200" />
                        <span>Train and compare Logistic Regression & Random Forest</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 size={18} className="text-blue-200" />
                        <span>Extract actionable business insights for retention</span>
                      </li>
                    </ul>
                  </div>
                  <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-blue-500 rounded-full opacity-20 blur-3xl"></div>
                </div>
              </div>
            )}

            {activeTab === 'collection' && (
              <div className="space-y-6">
                <SectionHeader title="Data Collection" icon={Database} step={1} />
                <p className="text-slate-600">
                  The first step involves loading the dataset. We use the Telco Customer Churn dataset, which contains information about 
                  customer demographics, services, and account information.
                </p>
                <CodeBlock code={`import pandas as pd
import numpy as np

# Load the dataset
df = pd.read_csv('telecom_churn.csv')

# Display first few rows
print(df.head())

# Dataset information
print(df.info())`} />
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                  <div className="p-4 bg-slate-50 border-b border-slate-100">
                    <h4 className="text-sm font-bold text-slate-700">Dataset Preview (First 5 Rows)</h4>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold">
                        <tr>
                          <th className="px-6 py-3">Tenure</th>
                          <th className="px-6 py-3">Monthly Charges</th>
                          <th className="px-6 py-3">Total Charges</th>
                          <th className="px-6 py-3">Contract</th>
                          <th className="px-6 py-3">Internet Service</th>
                          <th className="px-6 py-3">Churn</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {mockChurnData.slice(0, 5).map((row, i) => (
                          <tr key={i} className="hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4">{row.tenure}</td>
                            <td className="px-6 py-4">${row.MonthlyCharges}</td>
                            <td className="px-6 py-4">${row.TotalCharges}</td>
                            <td className="px-6 py-4">{row.Contract}</td>
                            <td className="px-6 py-4">{row.InternetService}</td>
                            <td className="px-6 py-4">
                              <span className={cn(
                                "px-2 py-1 rounded-full text-[10px] font-bold uppercase",
                                row.Churn === 'Yes' ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                              )}>
                                {row.Churn}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'exploration' && (
              <div className="space-y-6">
                <SectionHeader title="Data Exploration" icon={Search} step={2} />
                <p className="text-slate-600">
                  Exploration helps us understand the data distribution and identify missing values or anomalies. 
                  We check for nulls and look at the target variable (Churn) distribution.
                </p>
                <CodeBlock code={`# Check for missing values
print(df.isnull().sum())

# Explore churn distribution
import seaborn as sns
import matplotlib.pyplot as plt

sns.countplot(x='Churn', data=df)
plt.title('Churn Distribution')
plt.show()`} />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-6 text-slate-700">Churn Distribution</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={churnDist}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {churnDist.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend verticalAlign="bottom" height={36}/>
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-4 text-slate-700">Missing Values Summary</h4>
                    <div className="space-y-4">
                      {['customerID', 'gender', 'tenure', 'MonthlyCharges', 'TotalCharges', 'Churn'].map(col => (
                        <div key={col} className="flex items-center justify-between">
                          <span className="text-sm text-slate-500 font-mono">{col}</span>
                          <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded">0 Nulls</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'preprocessing' && (
              <div className="space-y-6">
                <SectionHeader title="Data Preprocessing" icon={Settings} step={3} />
                <p className="text-slate-600">
                  Raw data often needs cleaning. We convert types, handle missing values (like empty strings in TotalCharges), 
                  and encode categorical variables into numerical formats for the ML models.
                </p>
                <CodeBlock code={`# Convert TotalCharges to numeric, handling errors
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
df['TotalCharges'].fillna(df['TotalCharges'].median(), inplace=True)

# Encode categorical variables
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
df['Churn'] = le.fit_transform(df['Churn'])

# One-hot encoding for multi-category features
df = pd.get_dummies(df, drop_first=True)`} />
                
                <div className="bg-slate-900 rounded-2xl p-6 text-slate-300">
                  <h4 className="text-blue-400 font-bold mb-4 flex items-center gap-2">
                    <Terminal size={16} />
                    Preprocessing Steps Log
                  </h4>
                  <ul className="space-y-2 text-sm font-mono">
                    <li className="flex gap-2">
                      <span className="text-slate-500">[1/4]</span>
                      <span>TotalCharges: 11 empty strings found. Imputed with median.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="text-slate-500">[2/4]</span>
                      <span>Categorical: 16 columns identified for One-Hot Encoding.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="text-slate-500">[3/4]</span>
                      <span>Scaling: MonthlyCharges and tenure scaled using StandardScaler.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="text-slate-500">[4/4]</span>
                      <span>Split: 80% Training, 20% Testing set created.</span>
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {activeTab === 'eda' && (
              <div className="space-y-6">
                <SectionHeader title="Exploratory Data Analysis" icon={BarChart3} step={4} />
                <p className="text-slate-600">
                  EDA helps identify patterns. For example, we can see how tenure (how long they've been a customer) 
                  relates to churn. Newer customers tend to churn more frequently.
                </p>
                <CodeBlock code={`# Visualize Churn vs Tenure
plt.figure(figsize=(10,6))
sns.kdeplot(df[df['Churn'] == 0]['tenure'], label='No Churn', shade=True)
sns.kdeplot(df[df['Churn'] == 1]['tenure'], label='Churn', shade=True)
plt.title('Tenure Distribution by Churn')
plt.show()`} />

                <div className="grid grid-cols-1 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-6 text-slate-700">Monthly Charges vs Tenure (Color by Churn)</h4>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis type="number" dataKey="tenure" name="Tenure" unit="mo" axisLine={false} tickLine={false} />
                          <YAxis type="number" dataKey="MonthlyCharges" name="Monthly Charges" unit="$" axisLine={false} tickLine={false} />
                          <ZAxis type="number" range={[100, 100]} />
                          <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                          <Legend verticalAlign="top" height={36}/>
                          <Scatter name="No Churn" data={mockChurnData.filter(d => d.Churn === 'No')} fill="#3b82f6" />
                          <Scatter name="Churn" data={mockChurnData.filter(d => d.Churn === 'Yes')} fill="#ef4444" />
                        </ScatterChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'training' && (
              <div className="space-y-6">
                <SectionHeader title="Model Training" icon={Cpu} step={5} />
                <p className="text-slate-600">
                  We train two popular classification models: Logistic Regression (baseline) and Random Forest (ensemble). 
                  We split the data to ensure we evaluate on unseen data.
                </p>
                <CodeBlock code={`from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

X = df.drop('Churn', axis=1)
y = df['Churn']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Logistic Regression
lr = LogisticRegression()
lr.fit(X_train, y_train)

# Random Forest
rf = RandomForestClassifier(n_estimators=100)
rf.fit(X_train, y_train)`} />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-4 text-slate-700">Logistic Regression</h4>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-500">Accuracy</span>
                        <span className="font-bold text-blue-600">{modelMetrics.logisticRegression.accuracy * 100}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${modelMetrics.logisticRegression.accuracy * 100}%` }}
                          className="bg-blue-500 h-full"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-4 text-slate-700">Random Forest</h4>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-500">Accuracy</span>
                        <span className="font-bold text-green-600">{modelMetrics.randomForest.accuracy * 100}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${modelMetrics.randomForest.accuracy * 100}%` }}
                          className="bg-green-500 h-full"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'evaluation' && (
              <div className="space-y-6">
                <SectionHeader title="Model Evaluation" icon={CheckCircle2} step={6} />
                <p className="text-slate-600">
                  Evaluation metrics like F1-score and ROC-AUC are more important than accuracy for imbalanced churn data. 
                  The confusion matrix shows where the model makes mistakes.
                </p>
                <CodeBlock code={`from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

y_pred = rf.predict(X_test)

print(classification_report(y_test, y_pred))
print("ROC-AUC Score:", roc_auc_score(y_test, rf.predict_proba(X_test)[:, 1]))

# Confusion Matrix
sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d')
plt.show()`} />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-6 text-slate-700">Confusion Matrix (Random Forest)</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={confusionMatrix} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                          <XAxis type="number" axisLine={false} tickLine={false} />
                          <YAxis dataKey="actual" type="category" axisLine={false} tickLine={false} />
                          <Tooltip cursor={{ fill: '#f8fafc' }} />
                          <Legend />
                          <Bar dataKey="predictedNo" name="Predicted No" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                          <Bar dataKey="predictedYes" name="Predicted Yes" fill="#ef4444" radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-sm font-bold mb-6 text-slate-700">Feature Importance</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={featureImportance} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                          <XAxis type="number" hide />
                          <YAxis dataKey="feature" type="category" width={150} tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                          <Tooltip cursor={{ fill: '#f8fafc' }} />
                          <Bar dataKey="importance" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'insights' && (
              <div className="space-y-8">
                <SectionHeader title="Business Insights" icon={Lightbulb} step={7} />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-l-blue-500 border border-slate-100">
                      <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                        <FileText size={18} className="text-blue-500" />
                        Contract Type Matters
                      </h4>
                      <p className="text-sm text-slate-600">
                        Customers with <strong>Month-to-month</strong> contracts are significantly more likely to churn. 
                        Incentivizing long-term contracts (1-2 years) could reduce churn by up to 40%.
                      </p>
                    </div>
                    
                    <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-l-purple-500 border border-slate-100">
                      <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                        <Settings size={18} className="text-purple-500" />
                        Tech Support is Key
                      </h4>
                      <p className="text-sm text-slate-600">
                        Lack of <strong>Online Security</strong> and <strong>Tech Support</strong> is a major predictor of churn. 
                        Bundling these services might improve retention.
                      </p>
                    </div>

                    <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-l-red-500 border border-slate-100">
                      <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                        <DollarSign size={18} className="text-red-500" />
                        High Charges Impact
                      </h4>
                      <p className="text-sm text-slate-600">
                        Customers with high <strong>Monthly Charges</strong> but low tenure are at the highest risk. 
                        Targeted discounts for new high-value customers are recommended.
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-900 rounded-3xl p-8 text-white flex flex-col justify-center relative overflow-hidden">
                    <div className="relative z-10">
                      <h3 className="text-2xl font-bold mb-6">Strategic Recommendations</h3>
                      <div className="space-y-6">
                        <div className="flex gap-4">
                          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
                            <span className="font-bold text-blue-400">01</span>
                          </div>
                          <p className="text-slate-300 text-sm">Implement an automated early-warning system using the Random Forest model to flag high-risk customers.</p>
                        </div>
                        <div className="flex gap-4">
                          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
                            <span className="font-bold text-blue-400">02</span>
                          </div>
                          <p className="text-slate-300 text-sm">Offer loyalty rewards for customers reaching the 12-month and 24-month tenure milestones.</p>
                        </div>
                        <div className="flex gap-4">
                          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
                            <span className="font-bold text-blue-400">03</span>
                          </div>
                          <p className="text-slate-300 text-sm">Optimize the onboarding process for Fiber Optic customers, as they show higher initial churn rates.</p>
                        </div>
                      </div>
                    </div>
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500 rounded-full opacity-10 blur-2xl"></div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

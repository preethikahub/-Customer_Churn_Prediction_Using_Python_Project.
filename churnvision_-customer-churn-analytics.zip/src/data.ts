
export const mockChurnData = [
  { tenure: 1, MonthlyCharges: 29.85, TotalCharges: 29.85, Churn: "No", Contract: "Month-to-month", InternetService: "DSL" },
  { tenure: 34, MonthlyCharges: 56.95, TotalCharges: 1889.5, Churn: "No", Contract: "One year", InternetService: "DSL" },
  { tenure: 2, MonthlyCharges: 53.85, TotalCharges: 108.15, Churn: "Yes", Contract: "Month-to-month", InternetService: "DSL" },
  { tenure: 45, MonthlyCharges: 42.3, TotalCharges: 1840.75, Churn: "No", Contract: "One year", InternetService: "DSL" },
  { tenure: 2, MonthlyCharges: 70.7, TotalCharges: 151.65, Churn: "Yes", Contract: "Month-to-month", InternetService: "Fiber optic" },
  { tenure: 8, MonthlyCharges: 99.65, TotalCharges: 820.5, Churn: "Yes", Contract: "Month-to-month", InternetService: "Fiber optic" },
  { tenure: 22, MonthlyCharges: 89.1, TotalCharges: 1949.4, Churn: "No", Contract: "Month-to-month", InternetService: "Fiber optic" },
  { tenure: 10, MonthlyCharges: 29.75, TotalCharges: 301.9, Churn: "No", Contract: "Month-to-month", InternetService: "DSL" },
  { tenure: 28, MonthlyCharges: 104.8, TotalCharges: 3046.05, Churn: "Yes", Contract: "Month-to-month", InternetService: "Fiber optic" },
  { tenure: 62, MonthlyCharges: 56.15, TotalCharges: 3487.95, Churn: "No", Contract: "One year", InternetService: "DSL" },
  { tenure: 13, MonthlyCharges: 49.95, TotalCharges: 587.45, Churn: "No", Contract: "Month-to-month", InternetService: "DSL" },
  { tenure: 16, MonthlyCharges: 18.95, TotalCharges: 326.8, Churn: "No", Contract: "Two year", InternetService: "No" },
  { tenure: 58, MonthlyCharges: 100.35, TotalCharges: 5681.1, Churn: "No", Contract: "One year", InternetService: "Fiber optic" },
  { tenure: 49, MonthlyCharges: 103.7, TotalCharges: 5036.3, Churn: "Yes", Contract: "Month-to-month", InternetService: "Fiber optic" },
  { tenure: 25, MonthlyCharges: 105.5, TotalCharges: 2686.05, Churn: "No", Contract: "Month-to-month", InternetService: "Fiber optic" },
  { tenure: 69, MonthlyCharges: 113.25, TotalCharges: 7895.15, Churn: "No", Contract: "Two year", InternetService: "Fiber optic" },
  { tenure: 52, MonthlyCharges: 20.65, TotalCharges: 1022.95, Churn: "No", Contract: "One year", InternetService: "No" },
  { tenure: 71, MonthlyCharges: 106.7, TotalCharges: 7382.25, Churn: "No", Contract: "Two year", InternetService: "Fiber optic" },
  { tenure: 10, MonthlyCharges: 55.2, TotalCharges: 528.35, Churn: "Yes", Contract: "Month-to-month", InternetService: "DSL" },
  { tenure: 21, MonthlyCharges: 90.05, TotalCharges: 1862.9, Churn: "No", Contract: "Month-to-month", InternetService: "Fiber optic" },
];

export const featureImportance = [
  { feature: "Contract_Month-to-month", importance: 0.25 },
  { feature: "tenure", importance: 0.22 },
  { feature: "MonthlyCharges", importance: 0.18 },
  { feature: "InternetService_Fiber optic", importance: 0.15 },
  { feature: "TotalCharges", importance: 0.10 },
  { feature: "PaymentMethod_Electronic check", importance: 0.06 },
  { feature: "OnlineSecurity_No", importance: 0.04 },
];

export const modelMetrics = {
  logisticRegression: {
    accuracy: 0.79,
    f1: 0.78,
    auc: 0.84,
  },
  randomForest: {
    accuracy: 0.81,
    f1: 0.80,
    auc: 0.86,
  }
};

export const confusionMatrix = [
  { actual: "No", predictedNo: 1200, predictedYes: 150 },
  { actual: "Yes", predictedNo: 200, predictedYes: 450 },
];
